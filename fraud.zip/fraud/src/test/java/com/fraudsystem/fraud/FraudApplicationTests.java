package com.fraudsystem.fraud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FraudApplicationTests {

	@Test
	void contextLoads() {
	}

}
